<div style='width:100%;height:auto;margin:0 auto;'>
<p style='text-align:justify;'>Dear <strong><?php echo e($title); ?> <?php echo e($fullname); ?></strong> </p>

<p style='text-align:justify;margin-top: 25px;'>Your book service has been received. Please save this email for future reference.</p>
<p style='text-align:justify;'>Event: <strong>NOLTA2024</strong></p>
<p style='text-align:justify;'>Date: <strong>Dec. 3-6, 2024</strong></p>
<p style='text-align:justify;'>Venue: <strong>Ha long Bay, Vietnam<strong></p>

<p style='text-align:justify;margin-top: 25px;'><strong>Registration Details:</strong></p>
<p style='text-align:justify;'>Full name: <?php echo e($title); ?> <?php echo e($fullname); ?></p>
<p style='text-align:justify;'>Registration No.: <?php echo e($orderinfo); ?></p>
<p style='text-align:justify;'>Phone: <?php echo e($tel); ?></p>
<p style='text-align:justify;'>Email: <?php echo e($email); ?></p>
<p style='text-align:justify;'>Total fee: <b style="color:red;"><?php echo number_format($hdtotalall); ?> VND</b></p>

<?php if($type!=''): ?>
<?php
	$strCar=App\Models\Common::fnTransport($type);
	echo $strCar;
?>
<?php endif; ?>

<?php if($hdtype2!=''): ?>
<p style="margin: 0px;padding: 0px;">&nbsp;</p>
<?php
	$strCar2=App\Models\Common::fnTransport($hdtype2);
	echo $strCar2;
?>
<?php endif; ?>

<p style='text-align:justify;margin-top: 25px;'>
Please complete the payment using the following URL link:<br/>
<a style="background-color: #04245d;color:#fff;text-align: left;padding: 10px;border-radius: 5px;font-weight: bold;text-decoration: none;display: block;width: 588px;margin-top: 5px;max-width:100%;" href="<?php echo route('payment.trans',array($code1,$code2)); ?>"><?php echo route('payment.trans',array($code1,$code2)); ?></a>
</p>

<p style='text-align:justify;margin-top: 25px;'>
If you need any further assistance, please feel free to contact us at vicky@hoabinhtourist.com
</p>

<p style='text-align:justify;margin-top: 25px;'>
Kind regards,
</p>
<p style='text-align:justify;'>
<b>NOLTA2024 Organizers (Hoa Binh Team)</b>
</p>
 
</div><?php /**PATH /www/wwwroot/nolta2024.websitehoinghi.com/resources/views/emails/email_trans.blade.php ENDPATH**/ ?>